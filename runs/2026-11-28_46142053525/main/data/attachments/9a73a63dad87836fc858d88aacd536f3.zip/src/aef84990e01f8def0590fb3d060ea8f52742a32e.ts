import {
  test as base,
  expect,
  type APIRequestContext,
  type Browser,
  type BrowserContext,
  type Page,
} from '@playwright/test';
import { ApiClient, expectStatus, type Credentials } from '../api/client';
import type { Catalog, Lang } from '../api/schemas';
import { BugDialog } from '../components/bug-dialog';
import { Checklist } from '../components/checklist';
import { AskCard } from '../components/ask-card';
import { AskedCard } from '../components/asked-card';
import { Finish } from '../components/finish';
import { FeedbackDialog } from '../components/feedback-dialog';
import { FocusWizard } from '../components/focus-wizard';
import { ImportBanner } from '../components/import-banner';
import { ReplyOffer } from '../components/reply-offer';
import { Shell } from '../components/shell';
import { Tour } from '../components/tour';
import { env } from '../config/env';
import { ADMIN_EMAIL, DEFAULT_PASSWORD, uniqueEmail } from '../helpers/data';
import { googleLogin } from '../helpers/google';
import { playwrightCourse, type CourseChapter } from '../helpers/course';
import { AdminPage } from '../pages/admin-page';
import { AuthPage } from '../pages/auth-page';
import { CourseCatalogPage } from '../pages/course-catalog-page';
import { CoursePage } from '../pages/course-page';
import { CourseStepPage } from '../pages/course-step-page';
import { DashboardPage } from '../pages/dashboard-page';
import { FakeGoogle } from '../pages/fake-google-page';
import { InterviewPage } from '../pages/interview-page';
import { InterviewsPage } from '../pages/interviews-page';
import { KbPage } from '../pages/kb-page';
import { LeaderboardPage } from '../pages/leaderboard-page';
import { PlanPage } from '../pages/plan-page';
import { ProfilePage } from '../pages/profile-page';
import { QuizPage } from '../pages/quiz-page';
import { RecallPage } from '../pages/recall-page';

export type Device = 'desktop' | 'tablet' | 'phone';

/** Options a project (playwright.config.ts) or a file (`test.use`) can set. */
export interface FrameworkOptions {
  device?: Device;
  lang?: Lang;
  visitor?: Visitor;
}

/**
 * `new`: first visit (guest home, then the focus wizard and the dashboard tour); `skipped`: the
 * wizard skipped, the tour still ahead; `returning`: neither.
 */
export type Visitor = 'returning' | 'new' | 'skipped';

export interface TestUser extends Credentials {
  displayName: string;
  /** Access token from registration; valid for 15 minutes, enough for one test. */
  token: string;
}

interface TestFixtures {
  /** UI language pinned before the app loads. `test.use({ lang: 'en' })` for English. */
  lang: Lang;
  /** `test.use({ visitor: 'new' })` keeps the first visit; `'skipped'` keeps only the tour. */
  visitor: Visitor;
  /** Layout of the current project; page objects use it to hide desktop/phone differences. */
  device: Device;
  api: ApiClient;
  /** A fresh account created through the API and deleted after the test. */
  user: TestUser;
  /** Unused credentials for sign-up tests; the account is deleted after the test if it exists. */
  newCredentials: Credentials;
  /** A page signed in as `user` (API login inside the test's own browser context). */
  authedPage: Page;
  /** A page in a second browser context (another device) signed in as the same `user`. */
  secondPage: Page;
  /** A second fresh account, deleted after the test; its name differs from `user`'s. */
  otherUser: TestUser;
  /** A page in a second browser context signed in as `otherUser`. */
  otherPage: Page;
  /**
   * A page on /admin in a browser context of its own, signed in as the owner (`ADMIN_EMAIL`)
   * through the fake Google; the test's `page` stays a guest or `authedPage`.
   */
  adminPage: Page;
  /** The owner's access token, for arranging data through the API. */
  adminToken: string;
  admin: AdminPage;
  bugDialog: BugDialog;
  feedbackDialog: FeedbackDialog;
  replyOffer: ReplyOffer;
  /** An unused email for a Google-only account; the account is deleted after the test. */
  googleEmail: string;
  /**
   * Models a browser restart: a new context with the page's cookies and localStorage, minus the
   * session cookies (`expires: -1`) and sessionStorage, as a real browser drops them.
   */
  restartBrowser: (page: Page) => Promise<Page>;
  shell: Shell;
  importBanner: ImportBanner;
  focus: FocusWizard;
  tour: Tour;
  dashboard: DashboardPage;
  quiz: QuizPage;
  recall: RecallPage;
  auth: AuthPage;
  kb: KbPage;
  profile: ProfilePage;
  leaderboard: LeaderboardPage;
  fakeGoogle: FakeGoogle;
  interview: InterviewPage;
  plan: PlanPage;
  checklist: Checklist;
  finish: Finish;
  askCard: AskCard;
  askedCard: AskedCard;
  interviews: InterviewsPage;
  courses: CourseCatalogPage;
  coursePage: CoursePage;
  courseStep: CourseStepPage;
  /**
   * Moves the e2e API's clock to `at` (ISO), back to real time after the test. Server-global:
   * only in the `clock` project (one worker, after the others). A token minted before a jump looks
   * expired after it, so log in after setting it; a page also needs `page.clock` at the same
   * instant (the dashboard computes today itself).
   */
  serverClock: (at: string) => Promise<void>;
  /** Signs `user` in on `page` (refresh cookie, then the app restores the session on load). */
  signIn: (user: Credentials) => Promise<void>;
}

interface WorkerFixtures {
  /** GET /content/catalog, fetched once per worker: ids for data-driven tests, never volumes. */
  catalog: Catalog;
  /** The Playwright course's chapters with their step ids (src/helpers/course.ts), once per worker. */
  course: CourseChapter[];
}

export const test = base.extend<TestFixtures, WorkerFixtures>({
  lang: ['uk', { option: true }],
  device: ['desktop', { option: true }],
  visitor: ['returning', { option: true }],

  // Every page of every test starts with the same browser state, set before the app's own code
  // runs: no analytics, the chosen language and, for a returning visitor, no first-visit focus
  // wizard (it replaces the whole shell), no dashboard tour covering the UI and no sheets after
  // a finished quiz.
  // Keys: $APP_DIR/docs/test-ids.md.
  context: async ({ context, lang, visitor }, use) => {
    await prepareContext(context, lang, visitor);
    await use(context);
  },

  api: async ({ playwright }, use) => {
    const request = await playwright.request.newContext({ baseURL: env.apiURL });
    await use(new ApiClient(request));
    await request.dispose();
  },

  catalog: [
    async ({ playwright }, use) => {
      const request = await playwright.request.newContext({ baseURL: env.apiURL });
      await use(await new ApiClient(request).catalog());
      await request.dispose();
    },
    { scope: 'worker' },
  ],

  course: [
    async ({ playwright, catalog }, use) => {
      const request = await playwright.request.newContext({ baseURL: env.apiURL });
      await use(await playwrightCourse(new ApiClient(request), catalog));
      await request.dispose();
    },
    { scope: 'worker' },
  ],

  user: async ({ api }, use) => {
    assertNotProd('user');
    const credentials = { email: uniqueEmail(), password: DEFAULT_PASSWORD };
    const { accessToken, user } = await api.register({ ...credentials, displayName: 'PW Tester' });
    await use({ ...credentials, displayName: user.displayName, token: accessToken });
    await deleteAccountIfExists(api, credentials);
  },

  newCredentials: async ({ api }, use) => {
    assertNotProd('newCredentials');
    const credentials = { email: uniqueEmail('pw-ui'), password: DEFAULT_PASSWORD };
    await use(credentials);
    await deleteAccountIfExists(api, credentials);
  },

  authedPage: async ({ page, user, shell }, use) => {
    // page.request shares the cookie jar with the page: the refresh cookie (qa_rt) set by the
    // login lands in this context, and the app restores the session from it on load. Each test
    // gets its own user and session, so refresh-token rotation never logs out another test.
    await apiLogin(page.request, user);
    await page.goto('dash');
    await shell.expectSignedIn(user.email);
    await use(page);
  },

  secondPage: async ({ browser, lang, visitor, user }, use) => {
    const context = await newContext(browser, lang, visitor);
    const page = await context.newPage();
    await apiLogin(page.request, user);
    await use(page);
    await context.close();
  },

  otherUser: async ({ api }, use) => {
    assertNotProd('otherUser');
    const credentials = { email: uniqueEmail(), password: DEFAULT_PASSWORD };
    const { accessToken, user } = await api.register({ ...credentials, displayName: 'PW Other' });
    await use({ ...credentials, displayName: user.displayName, token: accessToken });
    await deleteAccountIfExists(api, credentials);
  },

  otherPage: async ({ browser, lang, visitor, otherUser }, use) => {
    const context = await newContext(browser, lang, visitor);
    const page = await context.newPage();
    await apiLogin(page.request, otherUser);
    await use(page);
    await context.close();
  },

  // One shared owner account for all workers: tests write only to rows they created and find them
  // by id or number.
  adminPage: async ({ browser, lang, visitor }, use) => {
    // The fake Google exists only on the e2e server.
    assertNotProd('adminPage');
    const context = await newContext(browser, lang, visitor);
    const page = await context.newPage();
    await googleLogin(page.request, ADMIN_EMAIL);
    await page.goto('admin');
    await expect(page.getByTestId('admin')).toBeVisible();
    await use(page);
    await context.close();
  },

  adminToken: async ({ api }, use) => {
    assertNotProd('adminToken');
    await use((await googleLogin(api.raw, ADMIN_EMAIL)).accessToken);
  },

  admin: async ({ adminPage }, use) => use(new AdminPage(adminPage)),
  bugDialog: async ({ page, shell }, use) => use(new BugDialog(page, shell)),
  feedbackDialog: async ({ page, shell }, use) => use(new FeedbackDialog(page, shell)),
  replyOffer: async ({ page }, use) => use(new ReplyOffer(page)),

  googleEmail: async ({ api }, use) => {
    // The fake Google exists only on the e2e server.
    assertNotProd('googleEmail');
    const email = uniqueEmail('pw-google');
    await use(email);
    // No password to log in with: sign in through Google again (it re-creates a deleted account)
    // and delete with that session.
    const { accessToken } = await googleLogin(api.raw, email);
    await api.deleteAccount(accessToken, email);
  },

  restartBrowser: async ({ browser, lang, visitor }, use) => {
    const contexts: BrowserContext[] = [];
    await use(async (page) => {
      const state = await page.context().storageState();
      const context = await newContext(browser, lang, visitor, {
        ...state,
        cookies: state.cookies.filter((cookie) => cookie.expires !== -1),
      });
      contexts.push(context);
      await page.context().close();
      return context.newPage();
    });
    for (const context of contexts) await context.close();
  },

  shell: async ({ page, device }, use) => use(new Shell(page, device)),
  importBanner: async ({ page }, use) => use(new ImportBanner(page)),
  dashboard: async ({ page }, use) => use(new DashboardPage(page)),
  quiz: async ({ page }, use) => use(new QuizPage(page)),
  recall: async ({ page }, use) => use(new RecallPage(page)),
  auth: async ({ page }, use) => use(new AuthPage(page)),
  kb: async ({ page }, use) => use(new KbPage(page)),
  profile: async ({ page }, use) => use(new ProfilePage(page)),
  leaderboard: async ({ page }, use) => use(new LeaderboardPage(page)),
  fakeGoogle: async ({ page }, use) => use(new FakeGoogle(page)),
  interview: async ({ page }, use) => use(new InterviewPage(page)),
  plan: async ({ page }, use) => use(new PlanPage(page)),
  checklist: async ({ page }, use) => use(new Checklist(page)),
  finish: async ({ page }, use) => use(new Finish(page)),
  askCard: async ({ page }, use) => use(new AskCard(page)),
  askedCard: async ({ page }, use) => use(new AskedCard(page)),
  interviews: async ({ page }, use) => use(new InterviewsPage(page)),
  courses: async ({ page }, use) => use(new CourseCatalogPage(page)),
  coursePage: async ({ page }, use) => use(new CoursePage(page)),
  courseStep: async ({ page }, use) => use(new CourseStepPage(page)),
  serverClock: async ({ api }, use) => {
    assertNotProd('serverClock');
    await use(async (at) => {
      await api.setClock({ at });
    });
    await api.setClock({ offsetMs: 0 });
  },
  signIn: async ({ page }, use) => use((user) => apiLogin(page.request, user)),
  focus: async ({ page }, use) => use(new FocusWizard(page)),
  tour: async ({ page }, use) => use(new Tour(page)),
});

export { expect };

/** Browser state set before the app's own code runs (keys: $APP_DIR/docs/test-ids.md). */
async function prepareContext(
  context: BrowserContext,
  lang: Lang,
  visitor: Visitor,
): Promise<void> {
  await context.addInitScript(
    ({ language, visitor }) => {
      localStorage.setItem('umami.disabled', '1');
      localStorage.setItem('qa-hub-lang', language);
      if (visitor === 'new') return;
      localStorage.setItem('qa-hub-focus', 'skipped');
      if (visitor === 'skipped') return;
      localStorage.setItem('qa-hub-tour-v1', JSON.stringify({ stage: 'done', weakHint: true }));
      // The content note after a finished quiz covers the result buttons.
      localStorage.setItem('qa-hub-content-note', 'dismissed');
    },
    { language: lang, visitor },
  );
}

/**
 * A context outside the test's own: browser.newContext() does not get the config's `use`, so the
 * options the app depends on are repeated here (playwright.config.ts).
 */
async function newContext(
  browser: Browser,
  lang: Lang,
  visitor: Visitor,
  storageState?: Awaited<ReturnType<BrowserContext['storageState']>>,
): Promise<BrowserContext> {
  const context = await browser.newContext({
    baseURL: env.baseURL,
    timezoneId: 'Europe/Kyiv',
    locale: 'uk-UA',
    storageState,
  });
  await prepareContext(context, lang, visitor);
  return context;
}

/** API login on a page's own request context: the refresh cookie lands in that browser. */
async function apiLogin(request: APIRequestContext, user: Credentials): Promise<void> {
  const res = await request.post(`${env.apiURL}auth/login`, {
    data: { email: user.email, password: user.password },
  });
  await expectStatus(res, 200);
}

/** Second line of defence after the @prod-safe grep: a mis-tagged test fails, no account is made. */
function assertNotProd(fixture: string): void {
  if (env.isProd)
    throw new Error(`The "${fixture}" fixture creates accounts; it never runs on prod.`);
}

/** Teardown helper: a test may have deleted the account itself or never created it. */
async function deleteAccountIfExists(api: ApiClient, credentials: Credentials): Promise<void> {
  const res = await api.raw.post('auth/login', { data: credentials });
  if (res.status() === 401) return;
  await expectStatus(res, 200);
  const { accessToken } = (await res.json()) as { accessToken: string };
  await api.deleteAccount(accessToken, credentials.email);
}
