import { expect, type APIRequestContext, type APIResponse } from '@playwright/test';
import type { z } from 'zod';
import {
  AdminBugReport,
  AdminBugReports,
  AdminFeedback,
  AdminFeedbackItem,
  AuthResponse,
  BugReportCreated,
  Catalog,
  ChatFeed,
  ChatMessage,
  CheckResult,
  Comments,
  DailyCount,
  FeedbackCreated,
  Health,
  ImportResult,
  KbChapter,
  Leaderboard,
  MyFeedback,
  Progress,
  Question,
  RateResult,
  RecallCard,
  SearchHits,
  User,
  type Lang,
  type UploadStatus,
} from './schemas';

/** What the dialogs send beside the text; `route` and `viewport` are required by the API. */
export const UPLOAD_CONTEXT = { route: '/dash', lang: 'uk', viewport: '1280x800' } as const;

export interface Credentials {
  email: string;
  password: string;
}

export interface RegisterInput extends Credentials {
  displayName?: string;
  timeZone?: string;
  remember?: boolean;
}

/** Body of POST /me/import ($APP_DIR packages/shared/src/import.schema.ts); unused parts stay `{}`. */
export interface ImportPayload {
  source: 'guest' | 'legacy';
  questions: Record<string, { lastResult: 0 | 1; attempts?: number }>;
  cards: Record<string, never>;
  articlesRead: Record<string, number>;
  attempts: Record<string, never>;
}

/**
 * Typed wrapper over Playwright's APIRequestContext for the QA Hub API (docs/brief.md §8).
 *
 * Two levels on purpose:
 * - typed methods (`health()`, `login()`, ...) for the happy path and test-data setup: they
 *   assert the status and parse the body with the zod schema, so a broken contract fails here,
 *   with a clear message, and the caller gets a typed object;
 * - `raw` for negative tests that need the status and the error body as they are, and for
 *   "this field must not be there" checks: zod drops unknown keys while parsing, so a parsed
 *   object can never show a leaked field.
 *
 * The context is created by the `api` fixture with baseURL = env.apiURL (ends with '/'), so all
 * paths here are relative and have no leading slash.
 */
export class ApiClient {
  constructor(readonly raw: APIRequestContext) {}

  health(): Promise<Health> {
    return this.getJson('health', Health);
  }

  catalog(lang: Lang = 'uk'): Promise<Catalog> {
    return this.getJson(`content/catalog?lang=${lang}`, Catalog);
  }

  questions(sectionId: string, lang: Lang = 'uk'): Promise<Question[]> {
    return this.getJson(`sections/${sectionId}/questions?lang=${lang}`, Question.array());
  }

  /**
   * Checks an answer. Without a token nothing is recorded, so `choice: null` is a safe way to
   * learn the correct option of a question for a deterministic UI test. With a token the answer
   * counts for that user (progress and XP). `first` marks a guest's first answer: the server
   * trusts it and counts it into the question's correct-answer share (`stat`).
   */
  checkAnswer(
    questionId: string,
    choice: number | null,
    token?: string,
    first?: boolean,
  ): Promise<CheckResult> {
    return this.postJson('quiz/check', { questionId, choice, first }, CheckResult, token);
  }

  async correctIndex(questionId: string): Promise<number> {
    return (await this.checkAnswer(questionId, null)).correctIndex;
  }

  recallCards(lang: Lang = 'uk'): Promise<RecallCard[]> {
    return this.getJson(`recall/cards?lang=${lang}`, RecallCard.array());
  }

  /** Rates a card 1..5 for the account; XP only for a new or due card, once per local day. */
  rateCard(token: string, cardId: string, rating: number): Promise<RateResult> {
    return this.postJson('me/recall/rate', { cardId, rating }, RateResult, token);
  }

  search(q: string, limit?: number): Promise<z.infer<typeof SearchHits>> {
    const params = new URLSearchParams({ q });
    if (limit !== undefined) params.set('limit', String(limit));
    return this.getJson(`kb/search?${params.toString()}`, SearchHits);
  }

  /** Article ids of a chapter, for `readArticle`. */
  chapter(chapterId: string): Promise<KbChapter> {
    return this.getJson(`kb/chapters/${chapterId}`, KbChapter);
  }

  leaderboard(period: 'all' | 'week' = 'all', token?: string): Promise<Leaderboard> {
    return this.getJson(`leaderboard?period=${period}`, Leaderboard, token);
  }

  register(input: RegisterInput): Promise<AuthResponse> {
    return this.postJson(
      'auth/register',
      { timeZone: 'Europe/Kyiv', ...input },
      AuthResponse,
      undefined,
      201,
    );
  }

  login(credentials: Credentials & { remember?: boolean }): Promise<AuthResponse> {
    return this.postJson('auth/login', credentials, AuthResponse);
  }

  /**
   * Rotates a refresh token sent in the body ("remember me" keeps it in `qa-hub-rt`). The server
   * prefers the `qa_rt` cookie, and this context keeps the cookie from its own login/register.
   */
  refresh(refreshToken: string): Promise<AuthResponse> {
    return this.postJson('auth/refresh', { refreshToken }, AuthResponse);
  }

  /** POST /auth/logout (204): ends every live token of the presented token's family. */
  async logout(refreshToken: string): Promise<void> {
    const res = await this.raw.post('auth/logout', { data: { refreshToken } });
    await expectStatus(res, 204);
  }

  me(token: string): Promise<User> {
    return this.getJson('auth/me', User, token);
  }

  progress(token: string): Promise<Progress> {
    return this.getJson('me/progress', Progress, token);
  }

  /** Moves guest (or legacy) progress into the account; the server recomputes the XP. */
  importProgress(token: string, payload: ImportPayload): Promise<ImportResult> {
    return this.postJson('me/import', payload, ImportResult, token);
  }

  /** Records a finished run; every question must have been answered in this sitting. */
  async finishQuiz(token: string, sectionId: string, questionIds: string[]): Promise<void> {
    const res = await this.raw.post('me/quiz/finish', {
      data: { sectionId, questionIds },
      headers: bearer(token),
    });
    await expectStatus(res, 200);
  }

  /** An untouched set takes the new size at once; a started one keeps its size until tomorrow. */
  async setDailyCount(token: string, count: number): Promise<DailyCount> {
    const res = await this.raw.put('me/daily-count', { data: { count }, headers: bearer(token) });
    await expectStatus(res, 200);
    return DailyCount.parse(await res.json());
  }

  /** Marks an article read for the account (what advances a READ_ARTICLE task). */
  async readArticle(token: string, articleId: string): Promise<void> {
    const res = await this.raw.post(`me/articles/${articleId}/read`, { headers: bearer(token) });
    await expectStatus(res, 200);
  }

  /** POST /me/password (204); other sessions of the account end, this one stays. */
  async changePassword(token: string, currentPassword: string, newPassword: string): Promise<void> {
    const res = await this.raw.post('me/password', {
      data: { currentPassword, newPassword },
      headers: bearer(token),
    });
    await expectStatus(res, 204);
  }

  postChat(token: string, text: string, anonymous = false): Promise<ChatMessage> {
    return this.postJson('chat/messages', { text, anonymous }, ChatMessage, token, 201);
  }

  sendBugReport(text: string, token?: string): Promise<z.infer<typeof BugReportCreated>> {
    const data = { ...UPLOAD_CONTEXT, text };
    return this.postJson('bug-reports', data, BugReportCreated, token, 201);
  }

  sendFeedback(rating: number, token?: string): Promise<z.infer<typeof FeedbackCreated>> {
    const data = { ...UPLOAD_CONTEXT, rating };
    return this.postJson('feedback', data, FeedbackCreated, token, 201);
  }

  adminBugReports(adminToken: string): Promise<AdminBugReports> {
    return this.getJson('admin/bug-reports', AdminBugReports, adminToken);
  }

  async setBugStatus(
    adminToken: string,
    id: number,
    status: UploadStatus,
  ): Promise<z.infer<typeof AdminBugReport>> {
    const res = await this.raw.patch(`admin/bug-reports/${id}`, {
      data: { status },
      headers: bearer(adminToken),
    });
    await expectStatus(res, 200);
    return AdminBugReport.parse(await res.json());
  }

  adminFeedback(adminToken: string): Promise<z.infer<typeof AdminFeedback>> {
    return this.getJson('admin/feedback', AdminFeedback, adminToken);
  }

  async replyToFeedback(
    adminToken: string,
    id: string,
    reply: string,
  ): Promise<z.infer<typeof AdminFeedbackItem>> {
    const res = await this.raw.put(`admin/feedback/${id}/reply`, {
      data: { reply },
      headers: bearer(adminToken),
    });
    await expectStatus(res, 200);
    return AdminFeedbackItem.parse(await res.json());
  }

  myFeedback(token: string): Promise<z.infer<typeof MyFeedback>> {
    return this.getJson('me/feedback', MyFeedback, token);
  }

  async chatMessages(): Promise<ChatMessage[]> {
    return (await this.getJson('chat/messages', ChatFeed)).messages;
  }

  /** Comments target a question (or another `targetType`) by id. */
  async postComment(token: string, targetId: string, text: string): Promise<void> {
    const res = await this.raw.post('comments', {
      data: { targetType: 'question', targetId, text },
      headers: bearer(token),
    });
    await expectStatus(res, 201);
  }

  async comments(targetId: string): Promise<Comments['items']> {
    const params = new URLSearchParams({ targetType: 'question', targetId });
    return (await this.getJson(`comments?${params}`, Comments)).items;
  }

  /** Deletes the account the token belongs to (DELETE /me, 204). */
  async deleteAccount(token: string, email: string): Promise<void> {
    const res = await this.raw.delete('me', {
      headers: bearer(token),
      data: { confirmEmail: email },
    });
    await expectStatus(res, 204);
  }

  private async getJson<S extends z.ZodType>(
    path: string,
    schema: S,
    token?: string,
  ): Promise<z.infer<S>> {
    const res = await this.raw.get(path, { headers: bearer(token) });
    await expectStatus(res, 200);
    return schema.parse(await res.json());
  }

  private async postJson<S extends z.ZodType>(
    path: string,
    data: unknown,
    schema: S,
    token?: string,
    status = 200,
  ): Promise<z.infer<S>> {
    const res = await this.raw.post(path, { data, headers: bearer(token) });
    await expectStatus(res, status);
    return schema.parse(await res.json());
  }
}

export function bearer(token?: string): Record<string, string> {
  return token ? { authorization: `Bearer ${token}` } : {};
}

/** Status check whose failure message shows the method, URL and body, not just "500 !== 200". */
export async function expectStatus(res: APIResponse, status: number): Promise<void> {
  if (res.status() === status) return;
  const body = await res.text().catch(() => '<no body>');
  expect(res.status(), `${res.url()} returned ${res.status()}: ${body.slice(0, 500)}`).toBe(status);
}
